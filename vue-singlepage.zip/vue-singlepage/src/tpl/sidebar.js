Vue.component('side-bar', {
    template: `
  <div>
  	<div>sidebar componentdfgfgdf</div>
  </div>
  `,
    mounted() {
        setTimeout(function () { }, 1000);

        // axios({
        //     method: 'get',
        //     url: "http://10.100.60.84:8529/BookAPI/find/all/books"
        // }).then(function (response) {
        //     console.log(response.data);

        // }).catch(error => {
        //     console.log(error.response.data);
        // });


    }
})
