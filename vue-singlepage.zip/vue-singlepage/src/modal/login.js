Vue.component('login-modal', {
    template: `
    <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <div class="loginmodal-container">
            <h1>Login to Your Account</h1><br>
            <form class="form-horizontal" role="form">
            
            </form>
            </div>
        </div>
    </div>
    </div>
  `,
    data: function () {
        return {

        }
    },
    mounted() {

    }
})