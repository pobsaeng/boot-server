Vue.component("modalTpl", {
  props: ["status"],
  template: `
    <transition name="modal">
    <div class="modal-mask" transition="modal" @click="close"><!--It's close, when press into body-->
      <div class="modal-wrapper">
        <div class="modal-container">

          <div class="modal-header">
            <slot name="header"></slot>
            <button @click="$emit('close')" type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
          </div>

          <div class="modal-body">
            <slot name="body"></slot>
          </div>
          <!--
          <div class="modal-footer">
            <slot name="footer"><button type="button" @click="$emit('close')" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button></slot>
          </div>
          -->
          
        </div>
      </div>
    </div>
  </transition>
  `,
  data: function() {
    return {};
  },
  methods: {
    close: function() {
      this.$emit(this.status);
    }
  },
  mounted() {}
});
