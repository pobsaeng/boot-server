Vue.component("thumbnail-scrolling", {
  template: `
    <div id="vue-instance" class="container">
    <div v-masonry transition-duration="0.3s" item-selector=".item" :origin-top="true" :horizontal-order="false">
        <div class="row">
            <div class="col-md-4" v-for="(post, index) in posts">
            <div class="card m-4" style="width: 18rem;">
            <img class="card-img-top" src="http://via.placeholder.com/350x150" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title"><strong>{{ post.title }}</strong></h5>
                <p class="card-text">sddf</p>
                </div>
            </div>
            </div>  
        </div>
    </div>
    </div>
    `,
  data: function() {
    return {
      posts: []
    };
  },
  created() {
    window.addEventListener("scroll", this.handleScroll);
    this.getPosts();
  },
  methods: {
    getPosts() {
      for (var i = 0; i < 16; i++) {
        this.posts.push({
          title: [],
          content: []
        });
      }
    },
    handleScroll() {
      let scrollHeight = window.scrollY;
      let maxHeight =
        window.document.body.scrollHeight -
        window.document.documentElement.clientHeight;

      if (scrollHeight >= maxHeight - 200) {
        this.getPosts();
      }
    },
    smartTrim(string, maxLength) {
      var trimmedString = string.substr(0, maxLength);
      return trimmedString.substr(
        0,
        Math.min(trimmedString.length, trimmedString.lastIndexOf(" "))
      );
    }
  }
});
