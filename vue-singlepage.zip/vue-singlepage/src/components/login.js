Vue.component('login', {
    template: `
    <div class="row content">
	<div class="col-md-4 mx-auto">
	
    <div class="card">
<article class="card-body">
	<h4 class="card-title text-center mb-4 mt-1">Sign in</h4>
	<hr>
	<p class="text-success text-center">Some message goes here</p>
	<form>
	<div class="form-group">
	<div class="input-group">
		<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-user"></i> </span>
		 </div>
		<input name="" class="form-control" placeholder="Email or login" type="email">
	</div> <!-- input-group.// -->
	</div> <!-- form-group// -->
	<div class="form-group">
	<div class="input-group">
		<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
		 </div>
	    <input class="form-control" placeholder="******" type="password">
	</div> <!-- input-group.// -->
	</div> <!-- form-group// -->
	<div class="form-group">
	<button type="submit" class="btn btn-primary btn-block"> Login  </button>
	</div> <!-- form-group// -->
	<p class="text-center"><a href="#" class="btn">Forgot password?</a></p>
	</form>



	<button type="button" class="btn btn-secondary"
							data-toggle="modal" data-target="#formModal">&#10010;</button>
							<form-modal></form-modal>
</article>
</div>



    </div>
    </div>
  `,
    data: function () {
        return {
			user: null,
			showModal: false
        }
    },
    mounted() {
        // const url = "http://localhost/vue-singlepage/assets/user.json";
        // axios.get(url).then(response => {
        //     this.user = response.data;
        //     console.log(this.user);
        // });
	}
})