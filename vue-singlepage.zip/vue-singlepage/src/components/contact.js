Vue.component("contact", {
  template: `
    <div class="row justify-content-center">
		<div class="col-sm-12">
        <div class="form-group">
        <div class="input-group mb-1">
            <div class="input-group-prepend">
                <div class="input-group-text"><i class="fa fa-user text-info"></i></div>
            </div>
            <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre y Apellido" required>
        </div>
    </div>
    <div class="form-group">
        <div class="input-group mb-1">
            <div class="input-group-prepend">
                <div class="input-group-text"><i class="fa fa-envelope text-info"></i></div>
            </div>
            <input type="email" class="form-control" id="nombre" name="email" placeholder="ejemplo@gmail.com" required>
        </div>
    </div>
    <div class="form-group">
        <div class="input-group mb-1">
            <div class="input-group-prepend">
                <div class="input-group-text"><i class="fa fa-comment text-info"></i></div>
            </div>
            <textarea rows="4" class="form-control" placeholder="Envianos tu Mensaje" required></textarea>
        </div>
    </div>
    <div class="form-group">
        <div class="input-group mb-1">
        <button slot="footer" type="button" @click="" class="btn btn-primary btn-sm" data-dismiss="modal">Save</button>
        </div>
    </div>

    </div>
	</div>
  `,
  data: function() {
    return {};
  },
  methods: {
    onSave(){
        alert("SDF");
    }
  }
  ,
  mounted() {
      document.addEventListener("keydown", (e) => {
      if (this.show && e.keyCode == 27) {
        this.close();
      }
    });
  }
});
