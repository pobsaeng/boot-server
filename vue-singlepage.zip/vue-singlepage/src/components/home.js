Vue.component("home", {
  template: `
  <div>
      <div>Home</div>
  </div>
  `,
  data: function() {
    return {
      showModal: false
    };
  },
  methods: {
    
  },
  mounted() {
    console.log("mounted!");
  }
});
