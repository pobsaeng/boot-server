Vue.component("common", {
    template: `
    <div class="row content justify-content-center">
    <div class="col-sm-12 mx-auto">

    <button id="show-modal" @click="showModal = true">Show Modal</button>
    <modalTpl v-if="showModal" @close="showModal = false" v-bind:status="''">
        <h3 slot="header">Custom header</h3>
        <contact slot="body"></contact>
        <div slot="footer">...</div>
    </modalTpl>

    <button type="button" data-toggle="modal" data-target="#confirm-modal">Small Message</button>
    <confirm-modal :head="'Alert Message'" :msg="'dfdffdf'"></confirm-modal>
    
    <div>
    <a href="#" data-toggle="modal" data-target="#login-modal">Login</a>
    </div>
    <login-modal></login-modal>

    <paging></paging>

    </div>
    </div>
    `,
    data: function() {
      return {
        showModal: false
      };
    },
    methods: {
      
    },
    mounted() {

    }
  });
  