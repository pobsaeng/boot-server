Vue.component("paging", {
  template: `
  <div id="paging-app">
  <div id="table-wrapper" class="ui container">
    <vuetable ref="vuetable"
      api-url="https://vuetable.ratiw.net/api/users"
      :fields="fields"
      :sort-order="sortOrder"
      :css="css.table"
      pagination-path=""
      :per-page="5"
      @vuetable:pagination-data="onPaginationData"
      @vuetable:loading="onLoading"        
      @vuetable:loaded="onLoaded"
    >
      <template slot="actions" scope="props">
        <div class="table-button-container">
            <button class="btn btn-warning btn-sm" @click="editRow(props.rowData)">
              <span class="fa fa-pencil"></span> Edit</button>&nbsp;&nbsp;
            <button class="btn btn-danger btn-sm" @click="deleteRow(props.rowData)">
              <span class="fa fa-trash-o"></span> Delete</button>&nbsp;&nbsp;
        </div>
        </template>
      </vuetable>
      <vuetable-pagination ref="pagination"
        :css="css.pagination"
        @vuetable-pagination:change-page="onChangePage"
      ></vuetable-pagination>
    </div>
  </div>
  `,
  events: {
    /** Start the loader ----------------------------------
    	 * Dispatched up the parent chain before vuetable
    	 * starts to request the data from the server
    	 */
      'vuetable:loading': function() {
          // display your loading notification
          console.log ("load started");
      },

       /** Disable the loader ---------------------------------
     * dispatched when vuetable receives response from server.
     * Response from server passed as the event argument
     */
      'vuetable:load-success': function(response) {
          // hide loading notification
          console.log ("load completed");
      },
  },
  data: function() {
    return {
      items: [],
      fields: [
        {
          name: "name",
          title: '<span class="orange fa fa-user-o"></span> Full Name',
          sortField: "name"
        },
        {
          name: "email",
          title: "Email",
          sortField: "email"
        },
        "birthdate",
        "nickname",
        {
          name: "gender",
          title: "Gender",
          sortField: "gender"
        },
        "__slot:actions"
      ],
      sortOrder: [{ field: "name", direction: "asc" }],
      css: {
        table: {
          tableClass: "table table-striped table-bordered table-hovered",
          loadingClass: "loading",
          ascendingIcon: "fa fa-arrow-up",
          descendingIcon: "fa fa-arrow-down",
          handleIcon: "fa fa-bars"
        },
        pagination: {
          infoClass: "pull-left",
          wrapperClass: "vuetable-pagination pull-right",
          activeClass: "btn-primary",
          disabledClass: "disabled",
          pageClass: "btn btn-border",
          linkClass: "btn btn-border",
          icons: {
            first: "",
            prev: "",
            next: "",
            last: ""
          }
        }
      }
    };
  },
  computed: {
    // httpOptions() {
    //   return { headers: { Authorization: "my-token" } }; //table props -> :http-options="httpOptions"
    // }
  },
  mounted() {
    this.loadData();
  },
  methods: {
    loadData() {
      //https://vuetable.ratiw.net/api/users"
      const url = "https://vuetable.ratiw.net/api/users";
      axios.get(url).then(response => {
        this.items = response.data.data;
        console.log(response.data.data);
      });
    },
    onPaginationData(paginationData) {
      this.$refs.pagination.setPaginationData(paginationData);
    },
    onChangePage(page) {
      this.$refs.vuetable.changePage(page);
    },
    editRow(rowData) {
      alert("You clicked edit on" + JSON.stringify(rowData));
    },
    deleteRow(rowData) {
      alert("You clicked delete on" + JSON.stringify(rowData));
    },
    onLoading() {
      console.log("loading... show your spinner here");
    },
    onLoaded() {
      console.log("loaded! .. hide your spinner here");
    }
  }
});
